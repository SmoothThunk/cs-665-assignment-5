
| CS-665       | Software Design & Patterns |
|--------------|----------------------------|
| Name         | Shriya Thakur              |
| Date         | 11/21/2023                 |
| Course       | Fall                       |
| Assignment # | 5                          |

# Assignment Overview
The purpose of this assignment is to identify and discuss three design patterns used within an open-source project of our choosing. The project being used is `JUnit4` which is a testing framework used by `Java`. The repo for the project itself can be found here: https://github.com/SmoothThunk/cs-665-assignment-5/upload

## Design Pattern 1 - Decorator

### Involved Classes with Roles

Component: `Test`\
Concrete Component: `TestCase`\
Base Decorator: `TestDecorator`\
Concrete Decorator: `TestSetup`, `RepeatedTest`

### Design Pattern Context

The `Decorator` design pattern provides a method for extending/modifying the behavior of a base object by using creating wrapper objects. 

`Test`: Acts as the common interface for both wrapper/wrapped objects. Defines the base methods for the component which is in this case a `test`.  
`TestCase`: Concrete implementation of component. Defines the basic behavior of the component's methods which can then be extended by attaching other decorators to it such as `TestSetup`, `RepeatedTest`.\
`TestDecorator`: Wraps the basic `test` component inside a `base decorator` which sets it up to be implemented by other `decorators`.\
`TestSetup`: Decorator setup with methods `setUp()` and `tearDown()`. The functions are empty to allow the decorator to be inherited by other `test` objects and allow the behavior to be defined inside the subclasses.\
`RepeatedTest`: Decorator setup to allow a `test` to be ran a specified number of times. 

### Additional Usage
Currently how the project is setup another class `TestRunner`, which prints a stack trace as tests are being executed, could also be setup to utilize the `Decorator` design pattern. A `TestRunner` could be setup as the component and then have decorators setup to handle different kinds of tests which would allow the `TestRunner` to dynamically accept new kinds of tests while its running and provide unique output based on the test being run. 

## Design Pattern 2 - Adapter

### Involved Classes with Roles

Adapter: `JUnit4TestAdapter`

### Design Pattern Context

The `Adapter` design pattern provides a method for allowing an older interface to be used by a new class that is incompatible with it. 

In this instance of the pattern, it has been altered significantly from what its usual architecture is when being implemented. Typically we would provide an instance of an `Adapter` class which implements the older `client interface` and then alters the behavior of the methods within the adapter class to be applicable to the new data type provided within the new class being adapted to. 

The implementation given in this usage of the pattern condenses it down to one class which we will simply refer to as the `Adapter` class.

`JUnit4TestAdapter`: The adapter functions by acting as a wrapper around generic test classes and providing methods within it to be compatible with an older version of `JUnit`. In this case the adapter works backwards in a sense, since it provides a method to continue utilizing `JUnit4` tests with `JUnit3`. 

### Additional Usage

The example above is not the most pratical usage of the design pattern. Within the context of `JUnit` it would make more sense to provide an adapter class to allow `JUnit4` tests to be used with `JUnit5` or a newer one. 

## Design Pattern 3 - Template Method

### Involved Classes with Roles

Abstract Class: `TestDecorator`\
Concrete Class: `TestSetup`, `RepeatableTest`

### Design Pattern Context

Coming back to our example of the `Decorator` design pattern the same classes utilized within that also use another design pattern the `Template Method` which usually functions by implementing an `Abstract Class` which provides a template method and breaks the other functionality of the class into multiple methods which act as steps to be listed inside the template method. The behaviors' of these `step` methods can then be modified inside a `concrete` implementation of the `abstract class`.

`TestDecorator`: This acts as an `Abstract Class` within the template method although it is not actually abstract and only provides the `template method`.\
`TestSetup`: As like in the `Decorator` design pattern, `TestSetup` will inherit `TestDecorator` gaining the `template method`. In this case it then provides the `step` methods as empty to be implemented by a further `test` subclass such as `TestCase`. So the the `Template Method` in this example is broken into more steps, but still functions the same. 

### Additional Usage

The `Template Method` design pattern is used a few more times throughout the `JUnit4` project. Most notably within the `ResultPrinter` class. But the `TestRunner` class could also be modified to utilize it as well, making it easier to format the steps the test runner takes when running each test case passed to it. 




